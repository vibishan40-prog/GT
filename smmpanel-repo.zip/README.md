# SMMPanel - Repo scaffold (frontend + server)

## What is included
- frontend/src/App.jsx (React single-file prototype, mocked API)
- server/ (Node/Express + Mongoose scaffold)
- infra/docker-compose.yml (Mongo + Redis + server + worker)
- infra/postman_collection.json (basic requests)
- worker.js (BullMQ worker example)
- README and package.json

## Quick start (development)
1. Copy `.env.example` into `.env` and fill values (MONGO_URI, REDIS_URL, JWT_SECRET, etc.)
2. From `/infra` run: `docker compose up --build`
3. Server will be available at `http://localhost:4000`

## Notes
- Replace mocked frontend `api` with real HTTP calls to the server endpoints.
- Configure Razorpay/Stripe keys in `.env` and wire webhooks to `/api/webhooks/*`.
