import React, { useState, useEffect, useRef } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, User, Settings, CreditCard, Edit2, Trash2, FileText } from "lucide-react";
import { motion } from "framer-motion";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

/* Frontend prototype single-file component (App.jsx)
   - This is the same, corrected React component you already reviewed in the canvas.
   - Replace mocked `api` with your backend endpoints when ready.
*/
const MOCK_DELAY = 150;
let servicesStore = [
  { id: 1, name: "Instagram Followers", pricePer100: 0.6, min: 100, max: 10000 },
  { id: 2, name: "YouTube Views", pricePer100: 0.4, min: 1000, max: 500000 },
  { id: 3, name: "TikTok Likes", pricePer100: 0.2, min: 50, max: 50000 }
];
let ordersStore = [
  { id: "ORD-1001", service: "Instagram Followers", quantity: 500, status: "Completed", date: "2025-10-10", user: 10 },
  { id: "ORD-1002", service: "YouTube Views", quantity: 2000, status: "Processing", date: "2025-10-12", user: 12 }
];
let refundsStore = [ { id: 'REF-5001', orderId: 'ORD-1002', amount: 5.0, status: 'Requested', requestedAt: '2025-10-13' } ];
let logsStore = [];
let usersStore = [ { id: 1, name: 'Admin User', role: 'admin' }, { id: 10, name: 'Alice', role: 'user' }, { id: 12, name: 'Bob', role: 'user' } ];

const clone = v => JSON.parse(JSON.stringify(v));

const api = {
  getServices: async () => { await new Promise(r => setTimeout(r, MOCK_DELAY)); return clone(servicesStore); },
  createService: async (payload) => { await new Promise(r => setTimeout(r, MOCK_DELAY)); const id = Math.max(0, ...servicesStore.map(s => s.id)) + 1; const s = { id, ...payload }; servicesStore.push(s); api.addLog(`Service created: ${s.name}`); return clone(s); },
  updateService: async (payload) => { await new Promise(r => setTimeout(r, MOCK_DELAY)); servicesStore = servicesStore.map(s => s.id === payload.id ? { ...s, ...payload } : s); api.addLog(`Service updated: ${payload.name}`); return clone(servicesStore.find(s => s.id === payload.id)); },
  deleteService: async (id) => { await new Promise(r => setTimeout(r, MOCK_DELAY)); servicesStore = servicesStore.filter(s => s.id !== id); api.addLog(`Service deleted: ${id}`); return true; },
  createOrder: async ({ serviceId, quantity, user }) => { await new Promise(r => setTimeout(r, MOCK_DELAY)); const svc = servicesStore.find(s => s.id === serviceId); if (!svc) throw new Error('Service not found'); if (typeof quantity !== 'number' || quantity < svc.min || quantity > svc.max) throw new Error('Quantity out of range'); const newOrder = { id: `ORD-${Math.floor(Math.random() * 90000) + 1000}`, service: svc.name, quantity, status: 'Queued', date: new Date().toISOString().slice(0,10), user: user?.id || null }; ordersStore = [newOrder, ...ordersStore]; api.addLog(`Order created: ${newOrder.id}`); return clone(newOrder); },
  createManualOrder: async ({ serviceId, quantity, targetUserId, adminId }) => { const created = await api.createOrder({ serviceId, quantity, user: { id: targetUserId } }); api.addLog(`Manual order ${created.id} placed by admin ${adminId} for user ${targetUserId}`); return created; },
  listOrders: async () => { await new Promise(r => setTimeout(r, MOCK_DELAY)); return clone(ordersStore); },
  listRefunds: async () => { await new Promise(r => setTimeout(r, MOCK_DELAY)); return clone(refundsStore); },
  requestRefund: async ({ orderId, amount }) => { await new Promise(r => setTimeout(r, MOCK_DELAY)); const id = `REF-${Math.floor(Math.random()*9000)+1000}`; const r = { id, orderId, amount, status: 'Requested', requestedAt: new Date().toISOString().slice(0,10) }; refundsStore = [r, ...refundsStore]; api.addLog(`Refund requested: ${id} for ${orderId}`); return clone(r); },
  processRefund: async (refundId, adminId) => { await new Promise(r => setTimeout(r, MOCK_DELAY)); refundsStore = refundsStore.map(x => x.id === refundId ? { ...x, status: 'Processed', processedAt: new Date().toISOString().slice(0,10), processedBy: adminId } : x); api.addLog(`Refund processed: ${refundId} by ${adminId}`); return clone(refundsStore.find(x => x.id === refundId)); },
  listUsers: async () => { await new Promise(r => setTimeout(r, MOCK_DELAY)); return clone(usersStore); },
  addLog: (msg) => { logsStore.unshift({ id: `LOG-${Date.now()}`, message: msg, time: new Date().toISOString() }); if (logsStore.length > 500) logsStore.length = 500; },
  listLogs: async () => { await new Promise(r => setTimeout(r, MOCK_DELAY)); return clone(logsStore); }
};

const formatCurrency = n => `$${Number(n || 0).toFixed(2)}`;

function AdminPanel({ services = [], onCreateService, onEditService, onDeleteService, onOpenManualOrder, refunds = [], onProcessRefund, logs = [], users = [] }) {
  return (
    <section className="mt-6 bg-white rounded-lg p-4 border">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold">Admin Dashboard</h3>
        <div className="flex items-center gap-2">
          <Button onClick={onOpenManualOrder} className="flex items-center gap-2"><Plus size={14} /> Manual Order</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="col-span-2">
          <div className="mb-3 flex items-center justify-between">
            <div className="text-sm text-slate-600">Services ({services.length})</div>
            <Button onClick={() => onCreateService()}>Add Service</Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {services.map(s => (
              <div key={s.id} className="p-3 border rounded flex items-center justify-between">
                <div>
                  <div className="font-semibold">{s.name}</div>
                  <div className="text-xs text-slate-500">{s.min} — {s.max} • {formatCurrency(s.pricePer100)}/100</div>
                </div>
                <div className="flex items-center gap-2">
                  <Button variant="ghost" onClick={() => onEditService(s)} className="flex items-center gap-2"><Edit2 size={14} />Edit</Button>
                  <Button variant="destructive" onClick={() => onDeleteService(s.id)} className="flex items-center gap-2"><Trash2 size={14} />Delete</Button>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div>
          <div className="mb-3 font-semibold">Recent Refunds</div>
          <div className="flex flex-col gap-2">
            {refunds.length === 0 && <div className="text-sm text-slate-500">No refunds</div>}
            {refunds.map(r => (
              <div key={r.id} className="p-2 border rounded flex items-center justify-between">
                <div className="text-sm">
                  <div className="font-mono text-xs">{r.id}</div>
                  <div className="text-xs">Order: {r.orderId} • {formatCurrency(r.amount)}</div>
                </div>
                <div className="flex items-center gap-2">
                  <div className="text-xs text-slate-600">{r.status}</div>
                  {r.status === 'Requested' && <Button onClick={() => onProcessRefund(r.id)} variant="ghost">Process</Button>}
                </div>
              </div>
            ))}
          </div>

          <div className="mt-4">
            <div className="font-semibold mb-2">Audit Logs</div>
            <div className="h-48 overflow-auto border rounded p-2 bg-slate-50 text-xs">
              {logs.slice(0, 50).map(l => (
                <div key={l.id} className="mb-2"><div className="font-mono text-xs">{l.time}</div><div>{l.message}</div></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function ManualOrderModal({ open, onClose, services = [], users = [], onConfirm, admin }) {
  const [svcId, setSvcId] = useState(null);
  const [qty, setQty] = useState(0);
  const [targetUser, setTargetUser] = useState(null);

  useEffect(() => {
    if (!open) return;
    if (services && services.length > 0) setSvcId(services[0].id);
    if (users && users.length > 0) setTargetUser(users[0].id);
    setQty(services && services.length > 0 ? services[0].min : 0);
  }, [open, services, users]);

  useEffect(() => {
    const svc = services.find(s => s.id === svcId);
    if (svc) setQty(prev => (prev < svc.min ? svc.min : prev > svc.max ? svc.max : prev));
  }, [svcId, services]);

  if (!open) return null;
  return (
    <div className="fixed inset-0 z-60 flex items-center justify-center bg-black/40 p-4">
      <div className="w-full max-w-xl bg-white rounded p-4">
        <div className="flex items-center justify-between mb-3">
          <h4 className="font-semibold">Manual Order (admin)</h4>
          <Button variant="ghost" onClick={onClose}>Close</Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div>
            <label className="text-xs">Service</label>
            <select value={svcId || ""} onChange={(e) => setSvcId(Number(e.target.value))} className="w-full border p-2 rounded">
              {services.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          </div>