const mongoose = require('mongoose');
const OrderSchema = new mongoose.Schema({
  orderId: { type: String, unique: true },
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  service: { type: mongoose.Schema.Types.ObjectId, ref: 'Service' },
  quantity: Number,
  price: Number,
  status: { type: String, enum: ['Queued','Processing','Completed','Failed'], default: 'Queued' },
  providerResponse: Object,
  createdAt: { type: Date, default: Date.now }
});
module.exports = mongoose.model('Order', OrderSchema);
