const mongoose = require('mongoose');
const RefundSchema = new mongoose.Schema({
  refundId: String,
  orderId: { type: mongoose.Schema.Types.ObjectId, ref: 'Order' },
  amount: Number,
  status: { type: String, enum: ['Requested','Processed','Rejected'], default: 'Requested' },
  requestedAt: Date,
  processedAt: Date,
  processedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
});
module.exports = mongoose.model('Refund', RefundSchema);
