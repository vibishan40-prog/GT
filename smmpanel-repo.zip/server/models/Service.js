const mongoose = require('mongoose');
const ServiceSchema = new mongoose.Schema({ name: String, min: Number, max: Number, pricePer100: Number, providerApiId: String });
module.exports = mongoose.model('Service', ServiceSchema);
