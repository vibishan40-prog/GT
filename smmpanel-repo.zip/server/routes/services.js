const express = require('express');
const Service = require('../models/Service');
const { authenticate, authorize } = require('../middleware/auth');
const router = express.Router();

router.get('/', async (req,res)=>{ const list = await Service.find(); res.json(list); });
router.post('/', authenticate, authorize(['admin']), async (req,res)=>{ const s = await Service.create(req.body); res.json(s); });
router.put('/:id', authenticate, authorize(['admin']), async (req,res)=>{ const s = await Service.findByIdAndUpdate(req.params.id, req.body, { new: true }); res.json(s); });
router.delete('/:id', authenticate, authorize(['admin']), async (req,res)=>{ await Service.findByIdAndDelete(req.params.id); res.json({ ok: true }); });

module.exports = router;
