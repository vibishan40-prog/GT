const express = require('express');
const Order = require('../models/Order');
const Service = require('../models/Service');
const { authenticate } = require('../middleware/auth');
const { Queue } = require('bullmq');
const IORedis = require('ioredis');
const connection = new IORedis(process.env.REDIS_URL);
const orderQueue = new Queue('orders', { connection });
const router = express.Router();

router.post('/', authenticate, async (req,res)=>{
  const { serviceId, quantity } = req.body;
  const svc = await Service.findById(serviceId);
  if(!svc) return res.status(400).json({ error: 'service not found' });
  if(quantity < svc.min || quantity > svc.max) return res.status(400).json({ error: 'quantity out of range' });
  const order = await Order.create({ orderId: `ORD-${Date.now()}`, user: req.user._id, service: svc._id, quantity, price: Math.round((svc.pricePer100 * quantity)/100 * 100)/100 });
  await orderQueue.add('process-order',{ orderId: order._id });
  res.json(order);
});

router.get('/:id', authenticate, async (req,res)=>{ const order = await Order.findById(req.params.id); if(!order) return res.status(404).json({}); res.json(order); });
module.exports = router;
