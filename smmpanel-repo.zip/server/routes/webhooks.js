const express = require('express');
const crypto = require('crypto');
const router = express.Router();

router.post('/razorpay', express.raw({ type: 'application/json' }), (req,res)=>{
  const secret = process.env.RZP_SECRET;
  const signature = req.headers['x-razorpay-signature'];
  const expected = crypto.createHmac('sha256', secret).update(req.body).digest('hex');
  if(signature !== expected) return res.status(400).end();
  const payload = JSON.parse(req.body.toString());
  res.json({ ok: true });
});

router.post('/stripe', express.raw({ type: 'application/json' }), (req,res)=>{
  const sig = req.headers['stripe-signature'];
  res.json({ ok: true });
});

module.exports = router;
