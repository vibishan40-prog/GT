const express = require('express');
const { authenticate, authorize } = require('../middleware/auth');
const Refund = require('../models/Refund');
const router = express.Router();

router.get('/refunds', authenticate, authorize(['admin']), async (req,res)=>{ const list = await Refund.find(); res.json(list); });
router.post('/refunds/:id/process', authenticate, authorize(['admin']), async (req,res)=>{ const id = req.params.id; const r = await Refund.findByIdAndUpdate(id,{ status: 'Processed', processedBy: req.user._id }, { new: true }); res.json(r); });
module.exports = router;
