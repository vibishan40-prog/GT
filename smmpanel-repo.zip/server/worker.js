require('dotenv').config();
const { Worker } = require('bullmq');
const IORedis = require('ioredis');
const mongoose = require('mongoose');
const Order = require('./models/Order');
const Service = require('./models/Service');

const connection = new IORedis(process.env.REDIS_URL);

const worker = new Worker('orders', async job => {
  const { orderId } = job.data;
  await mongoose.connect(process.env.MONGO_URI);
  const order = await Order.findById(orderId).populate('service');
  if(!order) throw new Error('order not found');
  order.status = 'Processing';
  await order.save();
  order.status = 'Completed';
  order.providerResponse = { delivered: true };
  await order.save();
}, { connection });

worker.on('failed', (job, err) => { console.error('Job failed', job.id, err); });
